package Service;

import Entity.Odontologo;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class OdontologoServiceTest {
    @Autowired
    OdontologoService odontologoService;

    @Test
    public void OdontologoTest() throws Exception{
        Odontologo odontologo1 = new Odontologo(3456, "Nicolas", "Montero");
        Odontologo odontologo2 = new Odontologo(7890, "Barbara", "Sabelli");

        Odontologo odontologoPrueba1 = odontologoService.guardar(odontologo1);
        Odontologo odontologoPrueba2 = odontologoService.guardar(odontologo2);

        assertEquals(1, odontologoPrueba1.getId());
        assertEquals(2, odontologoPrueba2.getId());
    }
}