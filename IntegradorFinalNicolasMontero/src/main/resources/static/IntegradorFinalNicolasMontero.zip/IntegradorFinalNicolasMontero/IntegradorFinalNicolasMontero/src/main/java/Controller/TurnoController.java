package Controller;
import Entity.Turno;
import Service.OdontologoService;
import Service.PacienteService;
import Service.TurnoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/turnos")
public class TurnoController {
    private final TurnoService turnoService;
    private final PacienteService pacienteService;
    private final OdontologoService odontologoService;

    @Autowired
    public TurnoController(TurnoService turnoService, PacienteService pacienteService, OdontologoService odontologoService) {
        this.turnoService = turnoService;
        this.pacienteService = pacienteService;
        this.odontologoService = odontologoService;
    }

    @PostMapping
    public ResponseEntity<Turno> registrarTurno(@RequestBody Turno turno){
        ResponseEntity<Turno> respuesta;
        if (odontologoService.buscar(turno.getOdontologo().getId())==null
                ||pacienteService.buscar(turno.getPaciente().getId())==null){
            respuesta=ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
        else{
            respuesta=ResponseEntity.ok(turnoService.guardar(turno));
        }
        return respuesta;
    }
    @PutMapping
    public ResponseEntity<Turno> actualizarTurno(@RequestBody Turno turno){
        ResponseEntity<Turno> respuesta;
        if (turnoService.buscar(turno.getId()).getId() == null){
            respuesta=ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
        else{
            respuesta=ResponseEntity.ok(turnoService.actualizar(turno));
        }
        return respuesta;
    }

    @GetMapping()
    public ResponseEntity<List<Turno>> buscarAllTurnos(){
        ResponseEntity<List<Turno>> respuesta;
        respuesta=ResponseEntity.ok(turnoService.buscarTodos());
        return respuesta;
    }

    @GetMapping("/{id}")
    public ResponseEntity<Turno> buscarTurno(@PathVariable Long id){
        ResponseEntity<Turno> respuesta;
        Turno turno = turnoService.buscar(id);
        if (turno.getId() == null){
            respuesta=ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        else {
            respuesta=ResponseEntity.ok(turno);
        }
        return respuesta;
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<Turno> eliminarTurno(@PathVariable Long id){
        ResponseEntity<Turno> respuesta;
        Turno turno = turnoService.buscar(id);

        if (turno.getId() == null){
            respuesta=ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        else {
            respuesta=ResponseEntity.ok(turno);
            turnoService.eliminar(id);
        }
        return respuesta;
    }
}
