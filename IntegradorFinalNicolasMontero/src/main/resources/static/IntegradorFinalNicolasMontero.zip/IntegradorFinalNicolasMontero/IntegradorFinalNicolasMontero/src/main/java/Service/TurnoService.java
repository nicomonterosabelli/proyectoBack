package Service;
import Entity.Turno;
import Repository.TurnoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TurnoService {
    private final TurnoRepository turnoRepository;
    @Autowired
    public TurnoService(TurnoRepository turnoRepository) {
        this.turnoRepository = turnoRepository;
    }


    public Turno guardar (Turno turno){

        return turnoRepository.save(turno);
    }
    public Turno buscar (Long id) {
        Optional <Turno> turno = turnoRepository.findById(id);
        if (turno.isPresent()){
            return turno.get();
        }
        return null;
    }

    public List<Turno> buscarTodos() {
        return turnoRepository.findAll();
    }
    public Turno actualizar (Turno turno) {return turnoRepository.save(turno);}
    public void eliminar (Long id) {turnoRepository.deleteById(id); }
}
