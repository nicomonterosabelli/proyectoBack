package Service;

import Entity.Paciente;
import Entity.Turno;
import Repository.DomicilioRepository;
import Repository.PacienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PacienteService {
    private final PacienteRepository pacienteRepository;
    private final DomicilioRepository domicilioRepository;
    @Autowired
    public PacienteService(PacienteRepository pacienteRepository, DomicilioRepository domicilioRepository) {
        this.domicilioRepository = domicilioRepository;
        this.pacienteRepository = pacienteRepository;
    }


    public Paciente guardar (Paciente paciente){
        return pacienteRepository.save(paciente);
    }
    public Paciente buscar (Long id) {
        Optional <Paciente> paciente = pacienteRepository.findById(id);
        if (paciente.isPresent()){
            return paciente.get();
        }
        return null;
    }
    public List<Paciente> buscarTodos() {
        return pacienteRepository.findAll();
    }
    public Paciente actualizar (Paciente paciente) {
        return pacienteRepository.save(paciente);
    }
    public void eliminar (Long id) {
        pacienteRepository.deleteById(id);
    }
}
