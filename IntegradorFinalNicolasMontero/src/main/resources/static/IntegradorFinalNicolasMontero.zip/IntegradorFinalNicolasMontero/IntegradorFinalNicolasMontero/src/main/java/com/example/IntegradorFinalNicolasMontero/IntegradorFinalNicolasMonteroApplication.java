package com.example.IntegradorFinalNicolasMontero;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IntegradorFinalNicolasMonteroApplication {

	public static void main(String[] args) {
		SpringApplication.run(IntegradorFinalNicolasMonteroApplication.class, args);
	}

}
