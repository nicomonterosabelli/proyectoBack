package Controller;
import Entity.Odontologo;
import Service.OdontologoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;


@RestController
@RequestMapping("/odontologos")
public class OdontologoController {
    private final OdontologoService odontologoService;

    @Autowired
    public OdontologoController(OdontologoService odontologoService) {

        this.odontologoService = odontologoService;
    }
    @PostMapping
    public ResponseEntity<Odontologo> registarOdontologo (@RequestBody Odontologo odontologo){
        ResponseEntity<Odontologo> respuesta;
        respuesta = ResponseEntity.ok(odontologoService.guardar(odontologo));
        return respuesta;
    }
    @GetMapping
    public ResponseEntity<List<Odontologo>> buscarAllOdontologos(){
        ResponseEntity<List<Odontologo>> respuesta;
        respuesta=ResponseEntity.ok(odontologoService.buscarTodos());
        return respuesta;
    }
    @GetMapping("/{id}")
    public ResponseEntity<Odontologo> buscarOdontologo(@PathVariable Long id) {
        ResponseEntity<Odontologo> respuesta;
        Odontologo odontologo = odontologoService.buscar(id);
        if (odontologo.getId() == null) {
            respuesta = ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        } else {
            respuesta = ResponseEntity.ok(odontologo);
        }
        return respuesta;
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Odontologo> eliminarOdontologo(@PathVariable Long id){
        ResponseEntity<Odontologo> respuesta;
        Odontologo odontologo = odontologoService.buscar(id);

        if (odontologo.getId() == null){
            respuesta=ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        else {
            respuesta=ResponseEntity.ok(odontologo);
            odontologoService.eliminar(id);
        }
        return respuesta;
    }

    @PutMapping
    public ResponseEntity<Odontologo> actualizarOdontologo(@RequestBody Odontologo odontologo){
        ResponseEntity<Odontologo> respuesta;
        if (odontologoService.buscar(odontologo.getId()) == null){
            respuesta=ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
        else{
            respuesta=ResponseEntity.ok(odontologoService.actualizar(odontologo));
        }
        return respuesta;
    }
}
